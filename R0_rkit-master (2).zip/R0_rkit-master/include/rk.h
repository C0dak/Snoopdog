int kcall(int cmd, char *arg);
