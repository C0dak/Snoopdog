#ifndef _CONFIG_H
#   define _CONFIG_H

#   define CMD_ROOT         0
#   define HIDDEN_PREFIX    ".X11-exec."

// Debugging definitions
#   define __DEBUG__        1   // General debugging statements
#   define __DEBUG_HOOK__   1   // Debugging of inline function hooking

#endif
