#define __IA32__ 1
