void kmem_init(void);
void wkml(unsigned long val, unsigned int offset);
int rkm(void *buf, unsigned int offset, int count);
int wkm(void *buf, unsigned int offset, int count);
