# R0-rkit
Ring-0 Kern > Ring-3 User Rootkit

[![Build 
Status](https://travis-ci.org/ManicSec/r0-rkit.svg?branch=master)](https://travis-ci.org/ManicSec/r0-rkit)
