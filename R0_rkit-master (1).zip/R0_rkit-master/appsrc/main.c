#define _GNU_SOURCE

#include <fcntl.h>
#include <stdio.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/*
static int rk_exec(const char *file, const char *cmdfmt, ...)
{
    int fd;

    char cmdbuf[20] = "";
    va_list args;

    va_start(args, cmdfmt);
    vsprintf(cmdbuf, cmdfmt, args);
    va_end(args);

    if((fd = open(file, O_WRONLY)) < 0)
        return -1;

    printf("Executing: %s\r\n", cmdbuf);

    write(fd, cmdbuf, strlen(cmdbuf) + 1);

    close(fd);

    return 0;
}
*/

int main(void)
{


    return 0;
}

